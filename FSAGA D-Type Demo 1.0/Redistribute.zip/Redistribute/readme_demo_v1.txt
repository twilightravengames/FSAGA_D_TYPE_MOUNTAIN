6/28/12

Fantasy Saga D-Type and Fantasy Saga D-Type Editor
Version 1.0
Readme

Written by (Ted) Walter Gress
http://development.twilightraven.com
Mac OS Build

Built on Mac OS X 10.7.4 Lion
Using the Eclipse Indigo IDE with CDT (C/C++ Tools)
XCode Mac 4.3 Linker
For run with Mach O 64 Binary Parser

Low level graphic and keyboard routines handled via 
ALLEGRO (http://www.allegro.cc) version 5.x


README:

Demo Version 1

Game Entry Point:

Redistribute/Fantasy_Saga_D_Type/Debug/Fantasy_Saga_D_Type

Game Controls:

Arrow keys direct the main character around the screen
The ENTER (RETURN) key, when pressed facing another character, talks to them.

Editor Entry Point:

Redistribute/Fantasy_Saga_D_Type/Debug/Fantasy_Saga_D_Type_Editor

The editor is fairly complex. Its controls (implemented and not implemented) are 
described in the text document, manual.txt, at:

Redistribute/Fantasy_Saga_D_Type/manual.txt

Map files have the extension .tpm


Please report all bugs to ted.gress@gmail.com

--------------



