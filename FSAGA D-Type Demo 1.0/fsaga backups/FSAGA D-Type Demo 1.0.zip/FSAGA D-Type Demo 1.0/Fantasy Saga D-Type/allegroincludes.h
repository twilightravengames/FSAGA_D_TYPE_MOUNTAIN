#ifndef ALLEGRO_INCLUDED
#define ALLEGRO_INCLUDED
#include "allegro5/allegro.h"
#include "allegro5/allegro_image.h"
#include "allegro5/allegro_font.h"
#include "allegro5/allegro_ttf.h"
#endif